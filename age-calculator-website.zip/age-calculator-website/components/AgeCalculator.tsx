'use client';

import { useMemo, useState } from 'react';
import { differenceInCalendarDays, format } from 'date-fns';
import { ArrowDownToLine, CalendarDays, Check, Clock3, Copy, Moon, RotateCcw, Share2, Sparkles, Sun, UsersRound, WandSparkles } from 'lucide-react';
import { calculateMetrics, calculateNextBirthday, dateFromInput, dateInputValue, formatLongDate } from '@/lib/age';

const today = new Date();
const initialDob = new Date(today.getFullYear() - 27, today.getMonth(), Math.min(today.getDate(), new Date(today.getFullYear() - 27, today.getMonth() + 1, 0).getDate()));
const number = (n: number) => new Intl.NumberFormat('en-US').format(n);
const displayDate = (value: string) => value ? `${value.slice(8, 10)}/${value.slice(5, 7)}/${value.slice(0, 4)}` : '';
const formatDateDraft = (value: string) => {
  const digits = value.replace(/\D/g, '').slice(0, 8);
  if (digits.length <= 2) return digits;
  if (digits.length <= 4) return `${digits.slice(0, 2)}/${digits.slice(2)}`;
  return `${digits.slice(0, 2)}/${digits.slice(2, 4)}/${digits.slice(4)}`;
};
const parseDisplayDate = (value: string) => {
  const digits = value.replace(/\D/g, '');
  if (digits.length !== 8) return '';
  const day = Number(digits.slice(0, 2)), month = Number(digits.slice(2, 4)), year = Number(digits.slice(4, 8));
  const daysInMonth = month >= 1 && month <= 12 ? new Date(year, month, 0).getDate() : 0;
  if (year < 1 || day < 1 || day > daysInMonth) return '';
  return `${digits.slice(4, 8)}-${digits.slice(2, 4)}-${digits.slice(0, 2)}`;
};

export default function AgeCalculator() {
  const [dob, setDob] = useState(dateInputValue(initialDob));
  const [dobText, setDobText] = useState(displayDate(dateInputValue(initialDob)));
  const [birthTime, setBirthTime] = useState('00:00');
  const [asOf, setAsOf] = useState(dateInputValue(today));
  const [asOfText, setAsOfText] = useState(displayDate(dateInputValue(today)));
  const [calculated, setCalculated] = useState(true);
  const [error, setError] = useState('');
  const [dark, setDark] = useState(false);
  const [copied, setCopied] = useState(false);
  const [compareA, setCompareA] = useState('');
  const [compareB, setCompareB] = useState('');
  const [compareAText, setCompareAText] = useState('');
  const [compareBText, setCompareBText] = useState('');
  const [compareResult, setCompareResult] = useState('');

  const birth = useMemo(() => dateFromInput(dob, birthTime), [dob, birthTime]);
  const target = useMemo(() => dateFromInput(asOf, asOf === dateInputValue(new Date()) ? format(new Date(), 'HH:mm') : birthTime), [asOf, birthTime]);
  const metrics = useMemo(() => {
    if (!calculated || !birth || !target || target.getTime() < birth.getTime()) return null;
    try { return calculateMetrics(birth, target); } catch { return null; }
  }, [birth, target, calculated]);
  const birthday = useMemo(() => birth ? calculateNextBirthday(birth, new Date()) : null, [birth]);
  const ageSummary = metrics ? `${metrics.years} years, ${metrics.months} months, ${metrics.days} days` : '';

  function calculate() {
    const validDob = parseDisplayDate(dobText), validAsOf = parseDisplayDate(asOfText);
    const b = dateFromInput(validDob, birthTime), t = dateFromInput(validAsOf, '00:00');
    if (!validDob || !validAsOf || !b || !t) { setError('Enter valid dates in DD/MM/YYYY format.'); setCalculated(false); return; }
    setDob(validDob); setAsOf(validAsOf);
    if (b.getTime() > Date.now()) { setError('Date of birth cannot be in the future.'); setCalculated(false); return; }
    if (t.getTime() < b.getTime()) { setError('The calculation date and time must be on or after the date of birth.'); setCalculated(false); return; }
    setError(''); setCalculated(true);
  }

  function reset() {
    const todayValue = dateInputValue(new Date());
    setDob(''); setDobText(''); setBirthTime('00:00'); setAsOf(todayValue); setAsOfText(displayDate(todayValue)); setCalculated(false); setError(''); setCopied(false);
  }

  function resultText() {
    if (!metrics || !birth || !birthday) return '';
    return `My age is ${ageSummary}.\nDate of birth: ${formatLongDate(birth)}\nBorn on: ${metrics.bornOn}\nTotal days lived: ${number(metrics.totalDays)}\nTotal weeks: ${number(metrics.totalWeeks)}\nNext birthday: ${formatLongDate(birthday.date)} (${birthday.days} days away)\nZodiac sign: ${metrics.zodiac}`;
  }

  async function copyResults() {
    try { await navigator.clipboard.writeText(resultText()); setCopied(true); window.setTimeout(() => setCopied(false), 1800); }
    catch { setError('Clipboard access was blocked by your browser. Please copy the result manually.'); }
  }

  async function shareResults() {
    const text = resultText();
    if (navigator.share) {
      try { await navigator.share({ title: 'My Age Calculator Results', text }); } catch (e) { if ((e as Error).name !== 'AbortError') setError('Sharing is not available right now.'); }
    } else await copyResults();
  }

  async function downloadPdf() {
    if (!metrics || !birth || !birthday) return;
    const { jsPDF } = await import('jspdf');
    const pdf = new jsPDF();
    pdf.setFont('helvetica', 'bold'); pdf.setFontSize(21); pdf.text('Your Age Calculator Results', 18, 22);
    pdf.setFont('helvetica', 'normal'); pdf.setFontSize(12);
    const lines = [
      `Exact age: ${ageSummary}`, `Date of birth: ${formatLongDate(birth)}`, `Calculated on: ${formatLongDate(target!)}`,
      `Born on: ${metrics.bornOn}`, `Total months: ${number(metrics.totalMonths)}`, `Total weeks: ${number(metrics.totalWeeks)}`,
      `Total days lived: ${number(metrics.totalDays)}`, `Total hours: ${number(metrics.totalHours)}`, `Total minutes: ${number(metrics.totalMinutes)}`,
      `Next birthday: ${formatLongDate(birthday.date)} (${birthday.days} days away)`, `Zodiac sign: ${metrics.zodiac}`,
    ];
    lines.forEach((line, i) => pdf.text(line, 18, 40 + i * 10));
    pdf.setFontSize(9); pdf.setTextColor(110); pdf.text('Generated by Age Calculator', 18, 175);
    pdf.save('age-calculator-results.pdf');
  }

  function compareAges() {
    const validA = parseDisplayDate(compareAText), validB = parseDisplayDate(compareBText);
    const a = dateFromInput(validA, '00:00'), b = dateFromInput(validB, '00:00');
    if (!a || !b) { setCompareResult('Enter both dates to compare ages.'); return; }
    const now = new Date();
    if (a > now || b > now) { setCompareResult('Birth dates cannot be in the future.'); return; }
    const older = a < b ? 'Person 1' : b < a ? 'Person 2' : 'Neither person';
    const days = Math.abs(differenceInCalendarDays(a, b));
    setCompareResult(a.getTime() === b.getTime() ? 'You were born on the same date.' : `${older} is older by ${number(days)} day${days === 1 ? '' : 's'} (${number(Math.floor(days / 365.2425))} years approximately).`);
  }

  const metricsList = metrics ? [
    { label: 'Total months', value: number(metrics.totalMonths), icon: CalendarDays, color: 'text-violet-500', tint: 'bg-violet-500/10' },
    { label: 'Total weeks', value: number(metrics.totalWeeks), icon: CalendarDays, color: 'text-blue-500', tint: 'bg-blue-500/10' },
    { label: 'Total days', value: number(metrics.totalDays), icon: Sparkles, color: 'text-amber-500', tint: 'bg-amber-500/10' },
    { label: 'Total hours', value: number(metrics.totalHours), icon: Clock3, color: 'text-emerald-500', tint: 'bg-emerald-500/10' },
    { label: 'Total minutes', value: number(metrics.totalMinutes), icon: Clock3, color: 'text-pink-500', tint: 'bg-pink-500/10' },
    { label: 'Born on', value: metrics.bornOn, icon: CalendarDays, color: 'text-indigo-500', tint: 'bg-indigo-500/10' },
  ] : [];

  return <main className={`site-shell ${dark ? 'dark-theme' : ''}`}>
    <header className="sticky top-0 z-30 border-b backdrop-blur-xl" style={{ borderColor: 'var(--line)', background: 'var(--surface)' }}>
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8">
        <a href="#home" className="flex items-center gap-2.5" aria-label="Agewise home"><span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-500 text-white shadow-lg shadow-indigo-500/20"><Clock3 size={21}/></span><span className="text-lg font-extrabold tracking-tight">age<span className="gradient-text">wise</span></span></a>
        <nav className="hidden items-center gap-7 text-sm font-medium md:flex"><a className="muted hover:text-indigo-500" href="#calculator">Calculator</a><a className="muted hover:text-indigo-500" href="#tools">Age tools</a><a className="muted hover:text-indigo-500" href="#how-it-works">How it works</a><a className="muted hover:text-indigo-500" href="#faq">FAQs</a></nav>
        <button onClick={() => setDark(!dark)} className="secondary-button flex h-10 w-10 items-center justify-center rounded-xl" aria-label={dark ? 'Switch to light mode' : 'Switch to dark mode'}>{dark ? <Sun size={18}/> : <Moon size={18}/>}</button>
      </div>
    </header>

    <section id="home" className="mx-auto grid max-w-7xl items-center gap-10 px-5 pb-12 pt-14 md:grid-cols-[1.04fr_.96fr] md:pb-16 md:pt-20 lg:px-8">
      <div className="animate-rise"><div className="mb-5 inline-flex items-center gap-2 rounded-full border px-3.5 py-2 text-xs font-semibold" style={{ borderColor: 'var(--line)', background: 'var(--surface)' }}><span className="h-2 w-2 rounded-full bg-emerald-500"/> Free, instant & accurate <Sparkles size={14} className="text-violet-500"/></div>
        <h1 className="max-w-2xl text-4xl font-black leading-[1.08] tracking-tight sm:text-5xl lg:text-6xl">Every year tells a story. <span className="gradient-text">Know yours.</span></h1>
        <p className="muted mt-5 max-w-xl text-base leading-7 sm:text-lg">Calculate your exact age in years, months, days, hours, and minutes. Find your next birthday and explore the time you’ve lived.</p>
        <div className="mt-7 flex flex-wrap gap-4 text-sm"><span className="flex items-center gap-2 muted"><Check size={16} className="text-emerald-500"/> No sign-up needed</span><span className="flex items-center gap-2 muted"><Check size={16} className="text-emerald-500"/> Your dates stay in your browser</span></div>
      </div>
      <div className="relative mx-auto flex w-full max-w-md items-center justify-center py-4"><div className="absolute h-64 w-64 rounded-full bg-gradient-to-br from-indigo-400/25 to-fuchsia-400/25 blur-3xl"/><div className="surface relative w-full rounded-[30px] p-6 sm:p-7"><div className="mb-6 flex items-center justify-between"><div><p className="muted text-xs font-semibold uppercase tracking-[.18em]">Time is precious</p><p className="mt-1 text-xl font-bold">Make every moment count</p></div><div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-500/10 text-indigo-500"><WandSparkles size={24}/></div></div><div className="grid grid-cols-2 gap-3"><div className="rounded-2xl bg-indigo-500/10 p-4"><p className="text-3xl font-black gradient-text">365</p><p className="muted mt-1 text-xs">days in a year*</p></div><div className="rounded-2xl bg-violet-500/10 p-4"><p className="text-3xl font-black gradient-text">12</p><p className="muted mt-1 text-xs">months in a year</p></div></div><div className="mt-3 flex items-center gap-3 rounded-2xl border p-4" style={{ borderColor: 'var(--line)' }}><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-500"><CalendarDays size={20}/></div><div><p className="text-sm font-bold">Your next chapter awaits</p><p className="muted mt-0.5 text-xs">Every day is part of your story.</p></div></div><p className="muted mt-3 text-[10px]">*A leap year has 366 days.</p></div></div>
    </section>

    <section id="calculator" className="section-anchor mx-auto max-w-7xl px-5 pb-16 lg:px-8"><div className="mb-7 text-center"><p className="text-xs font-bold uppercase tracking-[.2em] text-indigo-500">The age calculator</p><h2 className="mt-2 text-3xl font-extrabold tracking-tight sm:text-4xl">Calculate your exact age</h2><p className="muted mt-3">Enter your date of birth to get your personalized age breakdown.</p></div>
      <div className="surface mx-auto max-w-4xl rounded-[28px] p-5 sm:p-8"><div className="grid gap-5 sm:grid-cols-2"><div><label htmlFor="dob" className="mb-2 block text-sm font-semibold">Date of birth</label><input id="dob" type="text" inputMode="numeric" autoComplete="bday" placeholder="DD/MM/YYYY" maxLength={10} value={dobText} onChange={e => { const value = formatDateDraft(e.target.value); setDobText(value); setDob(parseDisplayDate(value)); setError(''); }} className="field" required/><p className="muted mt-2 text-xs">Enter as DD/MM/YYYY, for example 17/10/1999.</p></div><div><label htmlFor="birth-time" className="mb-2 block text-sm font-semibold">Time of birth <span className="muted font-normal">(optional)</span></label><input id="birth-time" type="time" value={birthTime} onChange={e => setBirthTime(e.target.value)} className="field"/><p className="muted mt-2 text-xs">Used for hours and minutes lived.</p></div><div className="sm:col-span-2"><label htmlFor="as-of" className="mb-2 block text-sm font-semibold">Calculate age as of</label><input id="as-of" type="text" inputMode="numeric" placeholder="DD/MM/YYYY" maxLength={10} value={asOfText} onChange={e => { const value = formatDateDraft(e.target.value); setAsOfText(value); setAsOf(parseDisplayDate(value)); }} className="field"/><p className="muted mt-2 text-xs">By default, this is set to today. Enter as DD/MM/YYYY.</p></div></div>
        {error && <p role="alert" className="mt-4 rounded-xl border border-red-300 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950 dark:text-red-200">{error}</p>}
        <div className="mt-6 flex flex-col gap-3 sm:flex-row"><button onClick={calculate} className="primary-button flex min-h-12 flex-1 items-center justify-center gap-2 rounded-xl px-5 py-3 text-sm font-bold"><Sparkles size={17}/> Calculate my age</button><button onClick={reset} className="secondary-button flex min-h-12 items-center justify-center gap-2 rounded-xl px-5 py-3 text-sm font-semibold"><RotateCcw size={16}/> Reset</button></div>
      </div>

      {metrics && birth && birthday && <div className="animate-rise mx-auto mt-8 max-w-5xl" aria-live="polite"><div className="overflow-hidden rounded-[28px] bg-gradient-to-br from-indigo-600 via-violet-600 to-blue-600 p-[1px] shadow-xl shadow-indigo-500/10"><div className="rounded-[27px] bg-white p-5 dark:bg-slate-950 sm:p-8"><div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-start"><div><p className="text-xs font-bold uppercase tracking-[.2em] text-indigo-500">Your age is</p><h3 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">{metrics.years} <span className="text-base font-semibold muted">years</span> {metrics.months} <span className="text-base font-semibold muted">months</span> {metrics.days} <span className="text-base font-semibold muted">days</span></h3><p className="muted mt-2 text-sm">Born {formatLongDate(birth)} · {metrics.bornOn}</p></div><div className="flex flex-wrap gap-2"><button onClick={copyResults} className="secondary-button flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold">{copied ? <Check size={16}/> : <Copy size={16}/>} {copied ? 'Copied' : 'Copy'}</button><button onClick={shareResults} className="secondary-button flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold"><Share2 size={16}/> Share</button><button onClick={downloadPdf} className="secondary-button flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold"><ArrowDownToLine size={16}/> PDF</button></div></div>
          <div className="mt-7 grid grid-cols-2 gap-3 sm:grid-cols-3"><div className="rounded-2xl bg-indigo-500/10 p-4"><p className="muted text-xs font-medium">Years</p><p className="mt-1 text-3xl font-black text-indigo-500">{number(metrics.years)}</p></div><div className="rounded-2xl bg-violet-500/10 p-4"><p className="muted text-xs font-medium">Months</p><p className="mt-1 text-3xl font-black text-violet-500">{number(metrics.months)}</p></div><div className="rounded-2xl bg-blue-500/10 p-4"><p className="muted text-xs font-medium">Days</p><p className="mt-1 text-3xl font-black text-blue-500">{number(metrics.days)}</p></div></div>
          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">{metricsList.map(item => { const Icon = item.icon; return <div key={item.label} className="metric-card rounded-2xl border p-4" style={{ borderColor: 'var(--line)' }}><div className={`mb-3 flex h-9 w-9 items-center justify-center rounded-xl ${item.tint} ${item.color}`}><Icon size={18}/></div><p className="muted text-xs">{item.label}</p><p className="mt-1 break-words text-xl font-extrabold">{item.value}</p></div>; })}</div>
          <div className="mt-4 grid gap-3 sm:grid-cols-2"><div className="flex items-center gap-4 rounded-2xl border p-4" style={{ borderColor: 'var(--line)' }}><div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500/10 text-amber-500"><Sparkles size={22}/></div><div><p className="muted text-xs">Next birthday</p><p className="mt-1 text-lg font-extrabold">{birthday.days === 0 ? 'Today! 🎉' : `${number(birthday.days)} days to go`}</p><p className="muted mt-0.5 text-xs">{formatLongDate(birthday.date)}</p></div></div><div className="flex items-center gap-4 rounded-2xl border p-4" style={{ borderColor: 'var(--line)' }}><div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-pink-500/10 text-pink-500"><WandSparkles size={22}/></div><div><p className="muted text-xs">Western zodiac sign</p><p className="mt-1 text-lg font-extrabold">{metrics.zodiac}</p><p className="muted mt-0.5 text-xs">Based on your birth date</p></div></div></div>
        </div></div></div>}
    </section>

    <section id="tools" className="section-anchor mx-auto max-w-7xl px-5 pb-16 lg:px-8"><div className="mb-7 text-center"><p className="text-xs font-bold uppercase tracking-[.2em] text-indigo-500">More useful tools</p><h2 className="mt-2 text-3xl font-extrabold tracking-tight">More ways to explore time</h2><p className="muted mt-3">Simple tools for your dates and milestones.</p></div><div className="grid gap-5 md:grid-cols-2"><div className="surface rounded-[26px] p-6 sm:p-7"><div className="mb-5 flex items-center gap-3"><div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-violet-500/10 text-violet-500"><CalendarDays size={21}/></div><div><h3 className="font-bold">Age on a specific date</h3><p className="muted text-sm">Use the main calculator’s “Calculate age as of” date.</p></div></div><p className="muted text-sm leading-6">Choose a past, present, or future date in the main calculator to calculate your age at that point in time. The next-birthday countdown is always based on today.</p><a href="#calculator" className="mt-5 inline-flex items-center gap-2 text-sm font-bold text-indigo-500">Open age calculator <span aria-hidden="true">→</span></a></div>
      <div className="surface rounded-[26px] p-6 sm:p-7"><div className="mb-5 flex items-center gap-3"><div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-blue-500/10 text-blue-500"><UsersRound size={21}/></div><div><h3 className="font-bold">Compare two ages</h3><p className="muted text-sm">Find out who was born first.</p></div></div><div className="grid gap-3 sm:grid-cols-2"><div><label htmlFor="compare-a" className="mb-1.5 block text-xs font-semibold">Person 1 date of birth</label><input id="compare-a" type="text" inputMode="numeric" placeholder="DD/MM/YYYY" maxLength={10} value={compareAText} onChange={e => { const value = formatDateDraft(e.target.value); setCompareAText(value); setCompareA(parseDisplayDate(value)); }} className="field"/></div><div><label htmlFor="compare-b" className="mb-1.5 block text-xs font-semibold">Person 2 date of birth</label><input id="compare-b" type="text" inputMode="numeric" placeholder="DD/MM/YYYY" maxLength={10} value={compareBText} onChange={e => { const value = formatDateDraft(e.target.value); setCompareBText(value); setCompareB(parseDisplayDate(value)); }} className="field"/></div></div><button onClick={compareAges} className="primary-button mt-4 rounded-xl px-4 py-3 text-sm font-bold">Compare ages</button>{compareResult && <p role="status" className="mt-4 rounded-xl bg-indigo-500/10 p-3 text-sm font-medium">{compareResult}</p>}</div></div></section>

    <section id="how-it-works" className="section-anchor mx-auto max-w-7xl px-5 pb-16 lg:px-8"><div className="surface rounded-[28px] p-6 sm:p-9"><div className="max-w-2xl"><p className="text-xs font-bold uppercase tracking-[.2em] text-indigo-500">Simple by design</p><h2 className="mt-2 text-3xl font-extrabold tracking-tight">How to calculate your age</h2><p className="muted mt-3 leading-7">Your calendar age is the time between your date of birth and a chosen date, expressed in complete years, months, and remaining days. This calculator accounts for real calendar month lengths and leap years rather than treating every month as the same length.</p></div><div className="mt-7 grid gap-4 md:grid-cols-3"><div className="rounded-2xl border p-5" style={{ borderColor: 'var(--line)' }}><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-500 text-sm font-black text-white">1</span><h3 className="mt-4 font-bold">Enter your birthday</h3><p className="muted mt-2 text-sm leading-6">Select your birth date. Add your birth time if you know it and want hour/minute totals.</p></div><div className="rounded-2xl border p-5" style={{ borderColor: 'var(--line)' }}><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-violet-500 text-sm font-black text-white">2</span><h3 className="mt-4 font-bold">Choose a calculation date</h3><p className="muted mt-2 text-sm leading-6">Use today, a past date, or a future date to calculate your age at that point in time.</p></div><div className="rounded-2xl border p-5" style={{ borderColor: 'var(--line)' }}><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-500 text-sm font-black text-white">3</span><h3 className="mt-4 font-bold">View and share results</h3><p className="muted mt-2 text-sm leading-6">Review your age breakdown, birthday countdown, and lifetime totals. Copy, share, or save a PDF.</p></div></div></div></section>

    <section id="faq" className="section-anchor mx-auto max-w-4xl px-5 pb-20 lg:px-8"><div className="mb-7 text-center"><p className="text-xs font-bold uppercase tracking-[.2em] text-indigo-500">FAQs</p><h2 className="mt-2 text-3xl font-extrabold tracking-tight">Frequently asked questions</h2></div><div className="space-y-3">{[
      ['How accurate is this age calculator?', 'It calculates calendar years, months, and days using actual date boundaries, including different month lengths and leap years. Total hours and minutes are calculated from the selected birth time to the start of the chosen calculation date.'],
      ['Can I calculate my age on a past date?', 'Yes. Use the “Calculate age as of” field and choose any date on or after your birth date, including a future date.'],
      ['Does the calculator account for leap years?', 'Yes. Calendar calculations use the real calendar, and the next birthday countdown safely handles dates such as February 29. In non-leap years, a February 29 birthday is observed by this tool on February 28 for countdown purposes.'],
      ['Are my personal details saved?', 'No. This website performs calculations in your browser and does not send your birth date to a server. Your browser may still retain normal local browser data, but this app does not intentionally store your dates.'],
      ['Why are total days different from years × 365?', 'Calendar years can contain 365 or 366 days, and months have different lengths. Total days are counted from the actual dates rather than multiplying the year count by 365.'],
      ['Can I download my results?', 'Yes. Select the PDF button in the results area to create a downloadable summary. Copy and Share are also available; Share uses your browser or device’s native sharing support when available.'],
    ].map(([q,a]) => <details key={q} className="surface group rounded-2xl p-5"><summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-bold">{q}<span className="text-xl text-indigo-500 transition-transform group-open:rotate-45">+</span></summary><p className="muted mt-3 pr-5 text-sm leading-7">{a}</p></details>)}</div></section>

    <footer className="border-t" style={{ borderColor: 'var(--line)' }}><div className="mx-auto flex max-w-7xl flex-col gap-5 px-5 py-8 sm:flex-row sm:items-center sm:justify-between lg:px-8"><a href="#home" className="flex items-center gap-2 font-extrabold"><span className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-violet-500 text-white"><Clock3 size={17}/></span>age<span className="gradient-text">wise</span></a><p className="muted text-sm">A little more clarity about your time. © {new Date().getFullYear()} Agewise.</p><div className="flex flex-wrap gap-4 text-sm"><a className="muted hover:text-indigo-500" href="mailto:hello@example.com?subject=Agewise%20Contact">Contact</a><a className="muted hover:text-indigo-500" href="#privacy">Privacy</a><a className="muted hover:text-indigo-500" href="#terms">Terms</a></div></div><div className="mx-auto max-w-7xl px-5 pb-6 lg:px-8"><details id="privacy" className="muted text-xs"><summary className="cursor-pointer">Privacy policy summary</summary><p className="mt-2 leading-5">Agewise calculates dates locally in your browser. It does not include analytics, account registration, a database, or server-side storage by default. If you deploy or modify this project, review any hosting, analytics, or third-party services you add.</p></details><details id="terms" className="muted mt-2 text-xs"><summary className="cursor-pointer">Terms summary</summary><p className="mt-2 leading-5">This tool is provided for general informational use. Calendar conventions can vary by context and jurisdiction; do not use this calculator as a substitute for official legal or identity records.</p></details></div></footer>
  </main>;
}
