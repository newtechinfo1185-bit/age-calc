import AgeCalculator from '@/components/AgeCalculator';

export default function Home() {
  const structuredData = {
    '@context': 'https://schema.org',
    '@type': 'WebApplication',
    name: 'Agewise Age Calculator',
    applicationCategory: 'UtilitiesApplication',
    operatingSystem: 'Any',
    description: 'Calculate exact calendar age in years, months, and days, plus total time lived and the next birthday countdown.',
    offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' },
  };
  return <><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}/><AgeCalculator /></>;
}
