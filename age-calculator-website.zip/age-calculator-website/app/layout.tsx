import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Free Age Calculator – Calculate Your Exact Age Online',
  description: 'Calculate your exact age in years, months, and days. Find your total days lived, next birthday countdown, and more with our free online age calculator.',
  keywords: ['Age Calculator', 'Online Age Calculator', 'Calculate My Age', 'Exact Age Calculator', 'Age Calculator by Date of Birth', 'Days Between Dates', 'Next Birthday Calculator'],
  openGraph: {
    title: 'Free Age Calculator – Calculate Your Exact Age Online',
    description: 'Find your exact age, total time lived, and next birthday countdown in seconds.',
    type: 'website',
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
