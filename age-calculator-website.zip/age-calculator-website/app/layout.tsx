import type { Metadata } from 'next';
import Script from 'next/script';
import './globals.css';

const adsensePublisherId = 'ca-pub-1060465619912753';

export const metadata: Metadata = {
  metadataBase: new URL('https://agecalculator.jrxpert.in'),
  alternates: { canonical: '/' },
  title: 'Free Age Calculator – Calculate Your Exact Age Online',
  description: 'Calculate your exact age in years, months, and days. Find your total days lived, next birthday countdown, and more with our free online age calculator.',
  keywords: ['Age Calculator', 'Online Age Calculator', 'Calculate My Age', 'Exact Age Calculator', 'Age Calculator by Date of Birth', 'Days Between Dates', 'Next Birthday Calculator'],
  openGraph: {
    title: 'Free Age Calculator – Calculate Your Exact Age Online',
    description: 'Find your exact age, total time lived, and next birthday countdown in seconds.',
    type: 'website',
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <head>
        <Script
          id="google-adsense"
          async
          strategy="beforeInteractive"
          crossOrigin="anonymous"
          src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${adsensePublisherId}`}
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
