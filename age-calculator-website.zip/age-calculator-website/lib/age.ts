import { differenceInCalendarDays, differenceInMinutes, differenceInWeeks, format, isValid, parseISO } from 'date-fns';

export type AgeParts = { years: number; months: number; days: number };

function dateAtSameTime(year: number, month: number, day: number, hours: number, minutes: number): Date {
  const d = new Date(year, month, day, hours, minutes, 0, 0);
  return d;
}

/** Calendar age, not an approximation based on average month length. */
export function calculateAgeParts(birth: Date, asOf: Date): AgeParts {
  if (asOf.getTime() < birth.getTime()) throw new Error('The calculation date must be on or after the date of birth.');
  let years = asOf.getFullYear() - birth.getFullYear();
  let months = asOf.getMonth() - birth.getMonth();
  let days = asOf.getDate() - birth.getDate();
  if (days < 0) {
    months -= 1;
    const previousMonthDays = new Date(asOf.getFullYear(), asOf.getMonth(), 0).getDate();
    days += previousMonthDays;
  }
  if (months < 0) { years -= 1; months += 12; }
  // If the birthday is on a later time of day, this calendar day is not fully reached yet.
  const anniversaryThisYear = dateAtSameTime(asOf.getFullYear(), birth.getMonth(), Math.min(birth.getDate(), new Date(asOf.getFullYear(), birth.getMonth() + 1, 0).getDate()), birth.getHours(), birth.getMinutes());
  if (asOf.getTime() < anniversaryThisYear.getTime() && asOf.getMonth() === birth.getMonth() && asOf.getDate() === birth.getDate()) {
    // Calendar parts already show zero days on this date; only adjust if the time has not arrived.
    days = 0;
  }
  return { years: Math.max(0, years), months: Math.max(0, months), days: Math.max(0, days) };
}

export function calculateNextBirthday(birth: Date, now: Date): { date: Date; days: number } {
  const year = now.getFullYear();
  const month = birth.getMonth();
  const day = Math.min(birth.getDate(), new Date(year, month + 1, 0).getDate());
  let next = new Date(year, month, day);
  next.setHours(0, 0, 0, 0);
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  if (next.getTime() < today.getTime()) {
    const nextYear = year + 1;
    next = new Date(nextYear, month, Math.min(birth.getDate(), new Date(nextYear, month + 1, 0).getDate()));
  }
  next.setHours(0, 0, 0, 0);
  return { date: next, days: Math.max(0, differenceInCalendarDays(next, today)) };
}

export function zodiacSign(date: Date): string {
  const m = date.getMonth() + 1, d = date.getDate();
  if ((m === 3 && d >= 21) || (m === 4 && d <= 19)) return 'Aries';
  if ((m === 4 && d >= 20) || (m === 5 && d <= 20)) return 'Taurus';
  if ((m === 5 && d >= 21) || (m === 6 && d <= 20)) return 'Gemini';
  if ((m === 6 && d >= 21) || (m === 7 && d <= 22)) return 'Cancer';
  if ((m === 7 && d >= 23) || (m === 8 && d <= 22)) return 'Leo';
  if ((m === 8 && d >= 23) || (m === 9 && d <= 22)) return 'Virgo';
  if ((m === 9 && d >= 23) || (m === 10 && d <= 22)) return 'Libra';
  if ((m === 10 && d >= 23) || (m === 11 && d <= 21)) return 'Scorpio';
  if ((m === 11 && d >= 22) || (m === 12 && d <= 21)) return 'Sagittarius';
  if ((m === 12 && d >= 22) || (m === 1 && d <= 19)) return 'Capricorn';
  if ((m === 1 && d >= 20) || (m === 2 && d <= 18)) return 'Aquarius';
  return 'Pisces';
}

export function formatLongDate(date: Date): string { return format(date, 'MMMM d, yyyy'); }
export function dateFromInput(value: string, time: string): Date | null {
  if (!value) return null;
  const [year, month, day] = value.split('-').map(Number);
  const [hour, minute] = (time || '00:00').split(':').map(Number);
  const d = new Date(year, month - 1, day, hour || 0, minute || 0, 0, 0);
  if (!isValid(d) || d.getFullYear() !== year || d.getMonth() !== month - 1 || d.getDate() !== day) return null;
  return d;
}

export function calculateMetrics(birth: Date, asOf: Date) {
  const parts = calculateAgeParts(birth, asOf);
  const totalMinutes = Math.max(0, differenceInMinutes(asOf, birth));
  const totalDays = Math.max(0, differenceInCalendarDays(asOf, birth));
  return {
    ...parts,
    totalMonths: parts.years * 12 + parts.months,
    totalWeeks: Math.floor(totalDays / 7),
    totalDays,
    totalHours: Math.floor(totalMinutes / 60),
    totalMinutes,
    bornOn: format(birth, 'EEEE'),
    zodiac: zodiacSign(birth),
  };
}

export function dateInputValue(date: Date): string { return format(date, 'yyyy-MM-dd'); }
